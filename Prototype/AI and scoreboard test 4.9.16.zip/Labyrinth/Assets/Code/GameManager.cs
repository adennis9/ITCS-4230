﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


public class GameManager
{
    private static GameManager _instance;
    public static GameManager Instance { get { return _instance ?? (_instance = new GameManager()); } }

    public int Points { get; private set; }

	private int _scoreMultiplier = 1;
    private GameManager()
    {
    }

    public void Reset()
    {
        Points = 0;
    }

    public void ResetPoints(int points)
    {
        Points = points;
    }

    public void AddPoints(int pointsToAdd)
    {
        Points += pointsToAdd;
    }
	public void increaseMultiplier()
	{
		_scoreMultiplier++;
	}

	public int getMultiplier()
	{
		return _scoreMultiplier;
	}

	public void resetMultiplier()
	{
		_scoreMultiplier = 1;
	}
}