﻿using UnityEngine;
using System.Collections;

public class ControllerPhysicsVolume2D : MonoBehaviour
{ 
    public ControllerParameters2D Parameters;
}
