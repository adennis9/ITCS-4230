﻿using UnityEngine;
using System.Collections;

public interface ITakeDamage
{
    void TakeDamage(int damage, GameObject instigator);


}
