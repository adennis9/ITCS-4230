
// This file has been included in a beta release, but is not yet included in a
// non-beta release. Since UnityPackages cannot delete files, only replace them
// this file is added to avoid old files causing compiler errors if a user upgrades
// from a beta it has been included in, to this version
